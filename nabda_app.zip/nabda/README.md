# نبضة — Nabda (تطوير: الحاج ياسر)

## التشغيل
```
flutter create --org com.hajyasser --project-name nabda .   # مرة واحدة لتوليد android/ و ios/
flutter pub get
flutter run
```
(الأمر الأول لا يستبدل lib/ ولا pubspec.yaml — إن سألك عن الاستبدال اختر الإبقاء على ملفاتك.)

## Android — AndroidManifest.xml (داخل <manifest>)
```
<uses-permission android:name="android.permission.INTERNET"/>
<uses-permission android:name="android.permission.ACCESS_FINE_LOCATION"/>
<uses-permission android:name="android.permission.ACCESS_COARSE_LOCATION"/>
<uses-permission android:name="android.permission.POST_NOTIFICATIONS"/>
```
وفي android/app/build.gradle: `compileOptions { coreLibraryDesugaringEnabled true }` و
`dependencies { coreLibraryDesugaring 'com.android.tools:desugar_jdk_libs:2.0.4' }` و minSdkVersion 21.

## iOS — Info.plist
`NSLocationWhenInUseUsageDescription` و `UIBackgroundModes` (fetch). iOS يحدد التنبيهات الخلفية بحسب نظامه.

## المصادر (كلها مجانية بدون مفاتيح)
Open-Meteo (طقس + جودة هواء) • USGS (زلازل) • RainViewer (رادار) • OpenStreetMap (خرائط).
