import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:intl/date_symbol_data_local.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:workmanager/workmanager.dart';
import 'core.dart';
import 'screens.dart';
import 'ui.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await initializeDateFormatting();
  final p = await SharedPreferences.getInstance();
  await initNotify();
  if (Platform.isAndroid || Platform.isIOS) {
    await Workmanager().initialize(callbackDispatcher, isInDebugMode: false);
    await Workmanager().registerPeriodicTask('quake-check', 'quakeCheck',
        frequency: const Duration(minutes: 15), constraints: Constraints(networkType: NetworkType.connected));
  }
  runApp(ProviderScope(overrides: [
    themeProvider.overrideWith((r) => ThemeMode.values[p.getInt('theme') ?? 2]),
    localeProvider.overrideWith((r) => p.getString('lang') ?? 'ar'),
  ], child: const App()));
}

ThemeData _theme(Brightness b) {
  final base = ThemeData(useMaterial3: true, brightness: b, colorSchemeSeed: const Color(0xFF0E7C86));
  return base.copyWith(textTheme: GoogleFonts.cairoTextTheme(base.textTheme));
}

class App extends ConsumerWidget {
  const App({super.key});
  @override
  Widget build(BuildContext c, WidgetRef ref) => MaterialApp(
      title: 'نبضة', debugShowCheckedModeBanner: false,
      theme: _theme(Brightness.light), darkTheme: _theme(Brightness.dark),
      themeMode: ref.watch(themeProvider), locale: Locale(ref.watch(localeProvider)),
      supportedLocales: const [Locale('ar'), Locale('en')],
      localizationsDelegates: const [GlobalMaterialLocalizations.delegate, GlobalWidgetsLocalizations.delegate, GlobalCupertinoLocalizations.delegate],
      home: const Shell());
}

class Shell extends StatefulWidget {
  const Shell({super.key});
  @override
  State<Shell> createState() => _ShellState();
}
class _ShellState extends State<Shell> {
  int i = 0;
  @override
  Widget build(BuildContext c) => Scaffold(
      body: IndexedStack(index: i, children: const [HomeScreen(), MapScreen(), AlertsScreen(), DetailsScreen()]),
      bottomNavigationBar: NavigationBar(selectedIndex: i, onDestinationSelected: (v) => setState(() => i = v), destinations: [
        NavigationDestination(icon: const Icon(Icons.home), label: c.tr('الرئيسية', 'Home')),
        NavigationDestination(icon: const Icon(Icons.map), label: c.tr('الخريطة', 'Map')),
        NavigationDestination(icon: const Icon(Icons.notifications), label: c.tr('التنبيهات', 'Alerts')),
        NavigationDestination(icon: const Icon(Icons.list_alt), label: c.tr('التفاصيل', 'Details')),
      ]));
}
