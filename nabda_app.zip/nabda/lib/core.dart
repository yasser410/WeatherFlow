import 'dart:convert';
import 'package:dio/dio.dart';
import 'package:flutter/material.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:geolocator/geolocator.dart';
import 'package:latlong2/latlong.dart';
import 'package:path/path.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:sqflite/sqflite.dart';
import 'package:workmanager/workmanager.dart';

const usgsDay = 'https://earthquake.usgs.gov/earthquakes/feed/v1.0/summary/all_day.geojson';
const usgsHour = 'https://earthquake.usgs.gov/earthquakes/feed/v1.0/summary/all_hour.geojson';
const usgsWeek = 'https://earthquake.usgs.gov/earthquakes/feed/v1.0/summary/2.5_week.geojson';

class Quake {
  final String id, place;
  final double mag, depth, lat, lon;
  final DateTime time;
  Quake(this.id, this.place, this.mag, this.depth, this.lat, this.lon, this.time);
}

List<Quake> parseQuakes(dynamic j) => (j['features'] as List)
    .where((f) => f['properties']['mag'] != null)
    .map((f) {
      final c = f['geometry']['coordinates'], p = f['properties'];
      return Quake(f['id'], p['place'] ?? '', (p['mag'] as num).toDouble(), (c[2] as num).toDouble(),
          (c[1] as num).toDouble(), (c[0] as num).toDouble(),
          DateTime.fromMillisecondsSinceEpoch(p['time']).toLocal());
    }).toList();

double distKm(LatLng a, Quake q) => Geolocator.distanceBetween(a.latitude, a.longitude, q.lat, q.lon) / 1000;

// ---------- SQLite ----------
class DB {
  static Database? _d;
  static Future<Database> get db async => _d ??= await openDatabase(
      join(await getDatabasesPath(), 'nabda.db'), version: 1, onCreate: (d, _) async {
    await d.execute('CREATE TABLE cache(k TEXT PRIMARY KEY, v TEXT)');
    await d.execute('CREATE TABLE alerts(id INTEGER PRIMARY KEY AUTOINCREMENT, qid TEXT, mag REAL, dist REAL, place TEXT, t INTEGER)');
  });
  static Future put(String k, String v) async =>
      (await db).insert('cache', {'k': k, 'v': v}, conflictAlgorithm: ConflictAlgorithm.replace);
  static Future<String?> get(String k) async {
    final r = await (await db).query('cache', where: 'k=?', whereArgs: [k]);
    return r.isEmpty ? null : r.first['v'] as String;
  }
  static Future addAlert(Quake q, double d) async {
    final x = await db;
    await x.insert('alerts', {'qid': q.id, 'mag': q.mag, 'dist': d, 'place': q.place, 't': q.time.millisecondsSinceEpoch});
    await x.execute('DELETE FROM alerts WHERE id NOT IN (SELECT id FROM alerts ORDER BY id DESC LIMIT 50)');
  }
  static Future<List<Map<String, Object?>>> alerts() async => (await db).query('alerts', orderBy: 'id DESC');
}

// ---------- Network (Dio: timeout 10s, retry x3) ----------
class RateLimited implements Exception {}
final _dio = Dio(BaseOptions(connectTimeout: const Duration(seconds: 10), receiveTimeout: const Duration(seconds: 10)));
bool offlineFlag = false;

Future<dynamic> fetch(String url, {Map<String, dynamic>? q}) async {
  final key = url + (q?.toString() ?? '');
  for (var i = 0;; i++) {
    try {
      final r = await _dio.get(url, queryParameters: q);
      await DB.put(key, jsonEncode(r.data is String ? jsonDecode(r.data) : r.data));
      return r.data is String ? jsonDecode(r.data) : r.data;
    } on DioException catch (e) {
      if (e.response?.statusCode == 429) throw RateLimited();
      if (i >= 2) {
        final c = await DB.get(key); // offline fallback: last saved real data
        if (c != null) { offlineFlag = true; return jsonDecode(c); }
        rethrow;
      }
      await Future.delayed(Duration(seconds: 1 << i));
    }
  }
}

Future<LatLng> locate() async {
  final p = await SharedPreferences.getInstance();
  try {
    var perm = await Geolocator.checkPermission();
    if (perm == LocationPermission.denied) perm = await Geolocator.requestPermission();
    if (perm == LocationPermission.whileInUse || perm == LocationPermission.always) {
      if (!await Geolocator.isLocationServiceEnabled()) await Geolocator.openLocationSettings();
      final pos = await Geolocator.getCurrentPosition(timeLimit: const Duration(seconds: 10));
      await p.setDouble('lat', pos.latitude); await p.setDouble('lon', pos.longitude);
      return LatLng(pos.latitude, pos.longitude);
    }
  } catch (_) {}
  return LatLng(p.getDouble('lat') ?? 31.2, p.getDouble('lon') ?? 29.9); // Alexandria default
}

class Data {
  final LatLng me; final Map w, aqi, radar; final List<Quake> day; final bool offline;
  Data(this.me, this.w, this.aqi, this.radar, this.day, this.offline);
}

Future<Data> loadData() async {
  offlineFlag = false;
  final me = await locate();
  final loc = {'latitude': me.latitude, 'longitude': me.longitude};
  final r = await Future.wait([
    fetch('https://api.open-meteo.com/v1/forecast', q: {...loc,
      'current': 'temperature_2m,relative_humidity_2m,weather_code,wind_speed_10m',
      'hourly': 'temperature_2m,precipitation_probability',
      'daily': 'temperature_2m_max,temperature_2m_min,sunrise,sunset,weather_code', 'timezone': 'auto'}),
    fetch('https://air-quality-api.open-meteo.com/v1/air-quality', q: {...loc, 'current': 'us_aqi'}),
    fetch('https://api.rainviewer.com/public/weather-maps.json'),
    fetch(usgsDay),
  ]);
  return Data(me, r[0], r[1], r[2], parseQuakes(r[3]), offlineFlag);
}

final dataProvider = FutureProvider<Data>((ref) => loadData());
final weekProvider = FutureProvider<List<Quake>>((ref) async => parseQuakes(await fetch(usgsWeek)));
final themeProvider = StateProvider<ThemeMode>((ref) => ThemeMode.system);
final localeProvider = StateProvider<String>((ref) => 'ar');

// ---------- Notifications + background ----------
final fln = FlutterLocalNotificationsPlugin();
Future<void> initNotify() async {
  await fln.initialize(const InitializationSettings(
      android: AndroidInitializationSettings('@mipmap/ic_launcher'), iOS: DarwinInitializationSettings()));
  await fln.resolvePlatformSpecificImplementation<AndroidFlutterLocalNotificationsPlugin>()?.requestNotificationsPermission();
}

Future<void> notifyQuake(Quake q, double d) => fln.show(q.id.hashCode, 'نبضة ⚠',
    'هزة أرضية بقوة ${q.mag} ريختر على بعد ${d.round()} كم',
    const NotificationDetails(
        android: AndroidNotificationDetails('quake', 'Earthquake alerts',
            importance: Importance.max, priority: Priority.high, playSound: true),
        iOS: DarwinNotificationDetails(presentSound: true, presentAlert: true)));

@pragma('vm:entry-point')
void callbackDispatcher() {
  Workmanager().executeTask((task, input) async {
    try {
      WidgetsFlutterBinding.ensureInitialized();
      await initNotify();
      final p = await SharedPreferences.getInstance();
      final me = LatLng(p.getDouble('lat') ?? 31.2, p.getDouble('lon') ?? 29.9);
      final r = await Dio().get(usgsHour, options: Options(receiveTimeout: const Duration(seconds: 10)));
      final seen = p.getStringList('seen') ?? [];
      for (final q in parseQuakes(r.data is String ? jsonDecode(r.data) : r.data)) {
        if (q.mag < 4.0 || seen.contains(q.id)) continue;
        seen.add(q.id);
        final d = distKm(me, q);
        if (d <= 300) { await notifyQuake(q, d); await DB.addAlert(q, d); }
      }
      await p.setStringList('seen', seen.length > 200 ? seen.sublist(seen.length - 200) : seen);
      return true;
    } catch (_) { return false; }
  });
}
