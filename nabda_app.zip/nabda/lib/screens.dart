import 'package:flutter/material.dart';
import 'package:flutter_map/flutter_map.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:intl/intl.dart';
import 'core.dart';
import 'ui.dart';

class HomeScreen extends ConsumerWidget {
  const HomeScreen({super.key});
  @override
  Widget build(BuildContext c, WidgetRef ref) => ref.watch(dataProvider).when(
      loading: () => const Center(child: CircularProgressIndicator()),
      error: (e, _) => ErrorView(e, () => ref.invalidate(dataProvider)),
      data: (d) {
        final cur = d.w['current'], code = cur['weather_code'] as int, w = wx(code);
        final near = d.day.where((q) => distKm(d.me, q) <= 500).toList()
          ..sort((a, b) => distKm(d.me, a).compareTo(distKm(d.me, b)));
        final red = d.day.any((q) => q.mag >= 4 && distKm(d.me, q) < 300);
        final orange = [65, 67, 75, 82, 86, 95, 96, 99].contains(code);
        final (rc, rt) = red ? (Colors.red, c.tr('خطر: زلزال قوي قريب', 'Danger: strong nearby quake'))
            : orange ? (Colors.orange, c.tr('تحذير: عاصفة / مطر شديد', 'Warning: storm / heavy rain'))
            : (Colors.green, c.tr('آمن', 'Safe'));
        final aqi = d.aqi['current']?['us_aqi'];
        return RefreshIndicator(
          onRefresh: () async { ref.invalidate(weekProvider); ref.invalidate(dataProvider); await ref.read(dataProvider.future); },
          child: ListView(padding: EdgeInsets.zero, children: [
            SizedBox(height: 300, child: Stack(fit: StackFit.expand, children: [
              Image.asset('assets/images/hero.jpg', fit: BoxFit.cover),
              const DecoratedBox(decoration: BoxDecoration(gradient: LinearGradient(
                  begin: Alignment.topCenter, end: Alignment.bottomCenter, colors: [Colors.black38, Colors.black87]))),
              SafeArea(child: Padding(padding: const EdgeInsets.all(16), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
                  Text('نبضة', style: Theme.of(c).textTheme.headlineMedium?.copyWith(color: Colors.white, fontWeight: FontWeight.bold)),
                  Row(children: [
                    IconButton(color: Colors.white, icon: const Icon(Icons.refresh), onPressed: () => ref.invalidate(dataProvider)),
                    IconButton(color: Colors.white, icon: const Icon(Icons.settings), onPressed: () => settingsSheet(c, ref)),
                  ]),
                ]),
                const Spacer(),
                Row(children: [
                  Icon(w.$1, color: Colors.white, size: 48), const SizedBox(width: 12),
                  Text('${(cur['temperature_2m'] as num).round()}°', style: const TextStyle(color: Colors.white, fontSize: 64, fontWeight: FontWeight.w300)),
                ]),
                Text(c.ar ? w.$2 : w.$3, style: const TextStyle(color: Colors.white, fontSize: 18)),
              ]))),
            ])),
            if (d.offline) Container(color: Colors.amber, padding: const EdgeInsets.all(8),
                child: Text(c.tr('أنت أوفلاين — آخر بيانات محفوظة', 'You are offline — showing last saved data'), textAlign: TextAlign.center, style: const TextStyle(color: Colors.black))),
            Padding(padding: const EdgeInsets.all(16), child: Column(children: [
              Card(color: rc.withOpacity(.18), child: ListTile(leading: Icon(Icons.shield, color: rc, size: 36),
                  title: Text(rt, style: TextStyle(color: rc, fontWeight: FontWeight.bold)))),
              Row(children: [
                _stat(Icons.air, c.tr('الرياح', 'Wind'), '${cur['wind_speed_10m']} km/h'),
                _stat(Icons.water_drop, c.tr('الرطوبة', 'Humidity'), '${cur['relative_humidity_2m']}%'),
                _stat(Icons.masks, c.tr('جودة الهواء', 'AQI'), aqi == null ? c.tr('غير متاح', 'N/A') : '$aqi'),
              ]),
              const SizedBox(height: 12),
              Align(alignment: AlignmentDirectional.centerStart,
                  child: Text(c.tr('أقرب الزلازل (500 كم)', 'Nearest quakes (500 km)'), style: Theme.of(c).textTheme.titleMedium)),
              if (near.isEmpty) Padding(padding: const EdgeInsets.all(20), child: Text(c.tr('لا يوجد نشاط زلزالي قريب', 'No nearby seismic activity')))
              else ...near.take(3).map((q) => QuakeTile(q, d.me)),
              const SizedBox(height: 16),
              Text(c.tr('تطوير: الحاج ياسر', 'Developed by Al-Hajj Yasser'), style: Theme.of(c).textTheme.labelMedium),
            ])),
          ]));
      });
  Widget _stat(IconData i, String l, String v) => Expanded(child: Card(child: Padding(padding: const EdgeInsets.all(12),
      child: Column(children: [Icon(i), const SizedBox(height: 4), Text(v, style: const TextStyle(fontWeight: FontWeight.bold)), Text(l, style: const TextStyle(fontSize: 12))]))));
}

class MapScreen extends ConsumerWidget {
  const MapScreen({super.key});
  @override
  Widget build(BuildContext c, WidgetRef ref) => ref.watch(dataProvider).when(
      loading: () => const Center(child: CircularProgressIndicator()),
      error: (e, _) => ErrorView(e, () => ref.invalidate(dataProvider)),
      data: (d) {
        final past = d.radar['radar']['past'] as List;
        final radar = '${d.radar['host']}${past.last['path']}/256/{z}/{x}/{y}/2/1_1.png';
        return FlutterMap(options: MapOptions(initialCenter: d.me, initialZoom: 5), children: [
          TileLayer(urlTemplate: 'https://tile.openstreetmap.org/{z}/{x}/{y}.png', userAgentPackageName: 'com.hajyasser.nabda'),
          TileLayer(urlTemplate: radar, opacity: .6),
          MarkerLayer(markers: [
            Marker(point: d.me, width: 36, height: 36, child: const Icon(Icons.my_location, color: Colors.blue, size: 32)),
            ...d.day.map((q) {
              final s = (q.mag.clamp(0, 8) * 5 + 12).toDouble();
              return Marker(point: LatLng(q.lat, q.lon), width: s, height: s, child: GestureDetector(
                  onTap: () => quakeSheet(c, q, d.me),
                  child: Container(decoration: BoxDecoration(shape: BoxShape.circle,
                      color: depthColor(q.depth).withOpacity(.55), border: Border.all(color: depthColor(q.depth), width: 2)))));
            }),
          ]),
          const SimpleAttributionWidget(source: Text('OpenStreetMap • RainViewer • USGS')),
        ]);
      });
}

class AlertsScreen extends StatefulWidget {
  const AlertsScreen({super.key});
  @override
  State<AlertsScreen> createState() => _AlertsState();
}
class _AlertsState extends State<AlertsScreen> {
  @override
  Widget build(BuildContext c) => SafeArea(child: Column(children: [
        ListTile(title: Text(c.tr('التنبيهات', 'Alerts'), style: Theme.of(c).textTheme.headlineSmall),
            subtitle: Text(c.tr('فحص USGS كل 15 دقيقة — زلزال 4.0+ ضمن 300 كم', 'USGS check every 15 min — M4.0+ within 300 km')),
            trailing: IconButton(icon: const Icon(Icons.refresh), onPressed: () => setState(() {}))),
        Expanded(child: FutureBuilder(future: DB.alerts(), builder: (_, s) {
          if (!s.hasData) return const Center(child: CircularProgressIndicator());
          final l = s.data!;
          if (l.isEmpty) return Center(child: Text(c.tr('لا توجد تنبيهات مسجلة بعد', 'No alerts recorded yet')));
          return ListView(children: l.map((a) => ListTile(
              leading: CircleAvatar(backgroundColor: Colors.red, foregroundColor: Colors.white, child: Text((a['mag'] as num).toStringAsFixed(1))),
              title: Text('${a['place']}'),
              subtitle: Text('${(a['dist'] as num).round()} km • ${DateFormat('d MMM HH:mm', c.ar ? 'ar' : 'en').format(DateTime.fromMillisecondsSinceEpoch(a['t'] as int))}'))).toList());
        })),
      ]));
}

class DetailsScreen extends ConsumerWidget {
  const DetailsScreen({super.key});
  @override
  Widget build(BuildContext c, WidgetRef ref) {
    final lang = c.ar ? 'ar' : 'en';
    return ref.watch(dataProvider).when(
        loading: () => const Center(child: CircularProgressIndicator()),
        error: (e, _) => ErrorView(e, () => ref.invalidate(dataProvider)),
        data: (d) {
          final h = d.w['hourly'], times = h['time'] as List, dl = d.w['daily'];
          var s = times.indexWhere((t) => (t as String).compareTo(d.w['current']['time']) >= 0);
          if (s < 0) s = 0;
          final n = (times.length - s).clamp(0, 24);
          final week = ref.watch(weekProvider);
          return SafeArea(child: ListView(padding: const EdgeInsets.all(12), children: [
            Text(c.tr('كل ساعة — 24 ساعة', 'Hourly — 24h'), style: Theme.of(c).textTheme.titleMedium),
            SizedBox(height: 110, child: ListView.builder(scrollDirection: Axis.horizontal, itemCount: n, itemBuilder: (_, i) {
              final k = s + i;
              return Card(child: Padding(padding: const EdgeInsets.all(10), child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
                Text((times[k] as String).substring(11, 16)),
                Text('${(h['temperature_2m'][k] as num).round()}°', style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
                Text('☔ ${h['precipitation_probability'][k] ?? '-'}%', style: const TextStyle(fontSize: 12)),
              ])));
            })),
            const SizedBox(height: 8),
            Text(c.tr('7 أيام', '7 days'), style: Theme.of(c).textTheme.titleMedium),
            for (var i = 0; i < (dl['time'] as List).length; i++) ListTile(
              leading: Icon(wx(dl['weather_code'][i]).$1),
              title: Text(DateFormat.EEEE(lang).format(DateTime.parse(dl['time'][i]))),
              subtitle: Text(c.ar ? wx(dl['weather_code'][i]).$2 : wx(dl['weather_code'][i]).$3),
              trailing: Text('${(dl['temperature_2m_max'][i] as num).round()}° / ${(dl['temperature_2m_min'][i] as num).round()}°')),
            const SizedBox(height: 8),
            Text(c.tr('زلازل 2.5+ عالمياً — آخر 7 أيام', 'Global M2.5+ quakes — last 7 days'), style: Theme.of(c).textTheme.titleMedium),
            week.when(
                loading: () => const Padding(padding: EdgeInsets.all(24), child: Center(child: CircularProgressIndicator())),
                error: (e, _) => SizedBox(height: 300, child: ErrorView(e, () => ref.invalidate(weekProvider))),
                data: (l) => Column(children: (l..sort((a, b) => b.time.compareTo(a.time))).map((q) => QuakeTile(q, d.me)).toList())),
          ]));
        });
  }
}
