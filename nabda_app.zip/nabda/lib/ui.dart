import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:intl/intl.dart';
import 'package:latlong2/latlong.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'core.dart';

extension Tr on BuildContext {
  bool get ar => Localizations.localeOf(this).languageCode == 'ar';
  String tr(String a, String e) => ar ? a : e;
}

(IconData, String, String) wx(int c) {
  if (c == 0) return (Icons.wb_sunny, 'صافٍ', 'Clear');
  if (c <= 3) return (Icons.cloud_queue, 'غائم جزئياً', 'Partly cloudy');
  if (c <= 48) return (Icons.foggy, 'ضباب', 'Fog');
  if (c <= 57) return (Icons.grain, 'رذاذ', 'Drizzle');
  if (c <= 67) return (Icons.water_drop, 'مطر', 'Rain');
  if (c <= 77) return (Icons.ac_unit, 'ثلج', 'Snow');
  if (c <= 82) return (Icons.umbrella, 'زخات مطر', 'Showers');
  if (c <= 86) return (Icons.ac_unit, 'زخات ثلج', 'Snow showers');
  return (Icons.thunderstorm, 'عاصفة رعدية', 'Thunderstorm');
}

Color depthColor(double d) => d < 70 ? Colors.red : d < 300 ? Colors.orange : Colors.blue;

class ErrorView extends StatelessWidget {
  final Object e; final VoidCallback retry;
  const ErrorView(this.e, this.retry, {super.key});
  @override
  Widget build(BuildContext c) => Center(
      child: Padding(padding: const EdgeInsets.all(24), child: Column(mainAxisSize: MainAxisSize.min, children: [
        const Icon(Icons.cloud_off, size: 64),
        const SizedBox(height: 12),
        Text(e is RateLimited ? c.tr('تم الوصول للحد المؤقت، حاول بعد دقيقة', 'Rate limit reached, try again in a minute')
            : c.tr('تعذر جلب البيانات الحقيقية. تحقق من الإنترنت.', 'Could not load real data. Check your connection.'),
            textAlign: TextAlign.center),
        const SizedBox(height: 16),
        FilledButton.icon(onPressed: retry, icon: const Icon(Icons.refresh), label: Text(c.tr('إعادة المحاولة', 'Retry'))),
      ])));
}

void quakeSheet(BuildContext c, Quake q, LatLng me) => showModalBottomSheet(context: c, builder: (_) => Padding(
    padding: const EdgeInsets.all(24),
    child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
      Text(q.place, style: Theme.of(c).textTheme.titleMedium),
      const Divider(height: 24),
      ListTile(leading: const Icon(Icons.speed), title: Text(c.tr('القوة', 'Magnitude')), trailing: Text('${q.mag}')),
      ListTile(leading: const Icon(Icons.vertical_align_bottom), title: Text(c.tr('العمق', 'Depth')), trailing: Text('${q.depth.toStringAsFixed(1)} km')),
      ListTile(leading: const Icon(Icons.schedule), title: Text(c.tr('الوقت المحلي', 'Local time')),
          trailing: Text(DateFormat('d MMM yyyy، HH:mm', c.ar ? 'ar' : 'en').format(q.time))),
      ListTile(leading: const Icon(Icons.social_distance), title: Text(c.tr('المسافة منك', 'Distance from you')), trailing: Text('${distKm(me, q).round()} km')),
    ])));

class QuakeTile extends StatelessWidget {
  final Quake q; final LatLng me;
  const QuakeTile(this.q, this.me, {super.key});
  @override
  Widget build(BuildContext c) => ListTile(
      onTap: () => quakeSheet(c, q, me),
      leading: CircleAvatar(backgroundColor: depthColor(q.depth), foregroundColor: Colors.white, child: Text(q.mag.toStringAsFixed(1))),
      title: Text(q.place, maxLines: 1, overflow: TextOverflow.ellipsis),
      subtitle: Text('${distKm(me, q).round()} km • ${DateFormat('d MMM HH:mm', c.ar ? 'ar' : 'en').format(q.time)}'));
}

void settingsSheet(BuildContext c, WidgetRef ref) => showModalBottomSheet(context: c, builder: (_) => Consumer(builder: (ctx, ref, _) {
      final mode = ref.watch(themeProvider), lang = ref.watch(localeProvider);
      return Padding(padding: const EdgeInsets.all(24), child: Column(mainAxisSize: MainAxisSize.min, children: [
        SegmentedButton<ThemeMode>(
            segments: [
              ButtonSegment(value: ThemeMode.light, icon: const Icon(Icons.light_mode), label: Text(ctx.tr('نهاري', 'Light'))),
              ButtonSegment(value: ThemeMode.dark, icon: const Icon(Icons.dark_mode), label: Text(ctx.tr('ليلي', 'Dark'))),
              ButtonSegment(value: ThemeMode.system, icon: const Icon(Icons.phone_android), label: Text(ctx.tr('تلقائي', 'Auto'))),
            ],
            selected: {mode},
            onSelectionChanged: (s) async {
              ref.read(themeProvider.notifier).state = s.first;
              (await SharedPreferences.getInstance()).setInt('theme', s.first.index);
            }),
        const SizedBox(height: 16),
        SegmentedButton<String>(
            segments: const [ButtonSegment(value: 'ar', label: Text('العربية')), ButtonSegment(value: 'en', label: Text('English'))],
            selected: {lang},
            onSelectionChanged: (s) async {
              ref.read(localeProvider.notifier).state = s.first;
              (await SharedPreferences.getInstance()).setString('lang', s.first);
            }),
        const Divider(height: 32),
        ListTile(leading: const Icon(Icons.code), title: Text(ctx.tr('المطور', 'Developer')), subtitle: Text(ctx.tr('الحاج ياسر', 'Al-Hajj Yasser'))),
      ]));
    }));
