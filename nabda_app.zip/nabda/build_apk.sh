#!/usr/bin/env bash
# يتطلب: Flutter مثبت (flutter doctor يظهر Android toolchain سليم)
set -e
[ -d android ] || flutter create --org com.hajyasser --project-name nabda --platforms android,ios .
python3 - <<'PY'
import re,os
m='android/app/src/main/AndroidManifest.xml'
s=open(m,encoding='utf8').read()
if 'ACCESS_FINE_LOCATION' not in s:
    perms=''.join(f'\n    <uses-permission android:name="android.permission.{p}"/>' for p in
      ['INTERNET','ACCESS_FINE_LOCATION','ACCESS_COARSE_LOCATION','POST_NOTIFICATIONS'])
    s=re.sub(r'(<manifest[^>]*>)',r'\1'+perms,s,count=1)
    s=re.sub(r'android:label="[^"]*"','android:label="نبضة"',s,count=1)
    open(m,'w',encoding='utf8').write(s)
for g,flag,dep in [('android/app/build.gradle.kts','isCoreLibraryDesugaringEnabled = true','\ndependencies {\n    coreLibraryDesugaring("com.android.tools:desugar_jdk_libs:2.0.4")\n}\n'),
                   ('android/app/build.gradle','coreLibraryDesugaringEnabled true',"\ndependencies {\n    coreLibraryDesugaring 'com.android.tools:desugar_jdk_libs:2.0.4'\n}\n")]:
    if os.path.exists(g):
        s=open(g).read()
        if 'desugar_jdk_libs' not in s:
            s=s.replace('compileOptions {','compileOptions {\n        '+flag,1)+dep
            open(g,'w').write(s)
        break
PY
flutter pub get
flutter build apk --release
echo "تم! الملف: build/app/outputs/flutter-apk/app-release.apk"
